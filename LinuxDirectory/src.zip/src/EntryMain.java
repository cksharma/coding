import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import dto.Command;
import dto.Results;
import dto.TreeNode;

import utils.Constants;
import utils.FileUtils;

/**
 * @author Tanvi
 * 
 */
public class EntryMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the input file path");
		String inputFilePath = scanner.nextLine();
		
		List<Command> commandList = FileUtils.parseInputFile(inputFilePath);
		
		List<Results> resultsList = processCommand(commandList);
		
		FileUtils.writeToFile(Constants.OUTPUT_FILE, resultsList);
		
	}

	/**
	 * @param commandList
	 */
	private static List<Results> processCommand(List<Command> commandList) {
		List <Results> resultsList =new ArrayList <Results>();
		TreeNode root=new TreeNode(null, Constants.ROOT, new HashSet<TreeNode>());
		TreeNode currentNode=root;
		
		for (Command command :commandList)
		{
			Results results=new Results(command, new ArrayList<String>());
			
			final String commandName = command.getCommandName();
		
			switch(commandName) {
				
				case Constants.MKDIR:
					Boolean result=currentNode.addChild(command.getArgument());
					if(result==false)
					{
						results.setMultiLineResults(Arrays.asList(Constants.FOLDER_PRESENT));
					}
					break;
					
				case Constants.CD:
					String argument = command.getArgument();
					TreeNode treeNode = currentNode.getChildByName(argument);
					if (treeNode != null) {
						currentNode = treeNode;
					} else {
						results.setMultiLineResults(Arrays.asList(Constants.FOLDER_DOESNT_EXIST));
					}
					break;
				case Constants.DIR:
					String resultStr = currentNode.getChildrenListStr();
					results.setMultiLineResults(Arrays.asList(resultStr));
					break;
				case Constants.UP:
					TreeNode myParent = currentNode.getMyParent();
					if (myParent == null) {
						results.setMultiLineResults(Arrays.asList(Constants.CANNOT_MOVE_UP));
					} else {
						currentNode = myParent;
					}
					break;
				default :
					throw new RuntimeException("Not a valid command");
			}	
			resultsList.add(results);						
		}
		return resultsList;
	}
}
