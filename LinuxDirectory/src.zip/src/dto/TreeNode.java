/**
 * 
 */
package dto;

import java.io.File;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import utils.Constants;

/**
 * @author Tanvi
 *
 */
public class TreeNode {
	TreeNode parent;
	String name;
	Set<TreeNode> childrenList;
	
	/**
	 * constructor for class TreeNode
	 * @param parent parent of the node
	 * @param name 
	 * @param childrenList
	 */
	public TreeNode(TreeNode parent, String name, Set<TreeNode> childrenList) {
		this.parent = parent;
		this.name = name;
		this.childrenList = childrenList;
	}
	
	public boolean addChild(String child){
		TreeNode treeNode = new TreeNode(this, child, new HashSet<TreeNode>());
		if (this.childrenList.contains(treeNode)) {
			return false;
		} 
		this.childrenList.add(treeNode);
		return true;
	}
	
	public TreeNode getChildByName(String child) {
		for (TreeNode childNode : childrenList) {
			if (childNode.name.equals(child)) {
				return childNode;
			}
		}
		return null;
	}
	
	public String getChildrenListStr() {
		TreeNode myNode = this;
		String parentStr = "";
		
		while (myNode != null) {
			parentStr = myNode.name + File.separator + parentStr;
			myNode = myNode.parent;
		}
		
		StringBuilder sb = new StringBuilder();
		int cnt = 0;
		for (TreeNode child : childrenList) {
			sb.append(child.name);
			
			if (++cnt % 10 == 0) {
				sb.append(Constants.EOF);
				continue;
			}
			
			while (sb.length() % Constants.WIDTH_DIR != 0) sb.append(" ");
		}
		parentStr = Constants.DIRECTORY_OF + " " + parentStr.substring(0, parentStr.length() - 1) + Constants.COLON;
		if (this.childrenList.isEmpty()) {
			sb = new StringBuilder(Constants.NO_SUB_DIRS);
		}
		return parentStr + Constants.EOF + sb.toString();
	}
	
	public TreeNode getMyParent() {
		return this.parent;
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(name);
	}

	@Override
	public boolean equals(Object obj) {
		TreeNode tNode = (TreeNode) obj;
		return this.name.equalsIgnoreCase(tNode.name);
	}
	
}
