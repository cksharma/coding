/**
 * 
 */
package dto;

import utils.Constants;

/**
 * @author Tanvi
 *
 */
public final class Command {
	private String commandName;
	private String argument;
	
	/**
	 * @param commandName
	 * @param argument
	 */
	public Command(String commandName, String argument) {
		super();
		this.commandName = commandName;
		this.argument = argument;
	}
	
	/**
	 * @return the commandName
	 */
	public String getCommandName() {
		return commandName;
	}
	/**
	 * @param commandName the commandName to set
	 */
	public void setCommandName(String commandName) {
		this.commandName = commandName;
	}
	/**
	 * @return the argument
	 */
	public String getArgument() {
		return argument;
	}
	/**
	 * @param argument the argument to set
	 */
	public void setArgument(String argument) {
		this.argument = argument;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append("Command: ").append(commandName);
		while (sb.length() < Constants.ARGUMENT_POS) {
			sb.append(" ");
		}
		if (argument != null && !argument.isEmpty())
			sb.append(argument);
		return sb.toString().trim();
	}	
}
