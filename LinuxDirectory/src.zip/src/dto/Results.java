/**
 * 
 */
package dto;

import java.util.List;

/**
 * @author Tanvi
 *
 */
public class Results {
	private Command command;
	private List<String> multiLineResults;
	
	/**
	 * @param command
	 * @param multiLineResults
	 */
	public Results(Command command, List<String> multiLineResults) {
		super();
		this.command = command;
		this.multiLineResults = multiLineResults;
	}
	
	/**
	 * @return the command
	 */
	public Command getCommand() {
		return command;
	}
	/**
	 * @param command the command to set
	 */
	public void setCommand(Command command) {
		this.command = command;
	}
	/**
	 * @return the multiLineResults
	 */
	public List<String> getMultiLineResults() {
		return multiLineResults;
	}
	/**
	 * @param multiLineResults the multiLineResults to set
	 */
	public void setMultiLineResults(List<String> multiLineResults) {
		this.multiLineResults = multiLineResults;
	}	
}
