/**
 * 
 */
package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import dto.Command;
import dto.Results;

/**
 * @author Tanvi
 *
 */
public final class FileUtils {
	public static void writeToFile(String fileName, List<Results> results) {
		try(FileWriter writer = new FileWriter(new File(fileName))) {
			writer.write(Constants.PROJECT_START + Constants.EOF);
			for (Results result : results) {
				writer.write(result.getCommand().toString() + Constants.EOF);
				for (String resStr : result.getMultiLineResults()) {
					writer.write(resStr + Constants.EOF);
				}
			}
			writer.write(Constants.PROJECT_END + Constants.EOF);
			writer.flush();
		} catch (IOException e) {
			// TODO wrap with custom exception
			e.printStackTrace();
		}
	}
	
	public static List<Command> parseInputFile(String filePath) {
		List<Command> commandList = new ArrayList<>();
		try(FileReader reader = new FileReader(filePath)) {
			BufferedReader buffer = new BufferedReader(reader);
			String line;
			while ((line = buffer.readLine()) != null) {
				line = line.trim();
				if (line.isEmpty()) continue;
				
				String[] commandDetails = line.split(Constants.COMMAND_SPLIT_REGEX);
				String commandName = commandDetails[0];
				String commandArgs = commandDetails.length > 1 ? commandDetails[1] : null;
				Command commandObj = new Command(commandName, commandArgs);
				commandList.add(commandObj);
			}
		} catch (FileNotFoundException e) {
			// TODO wrap with custom exception
			e.printStackTrace();
		} catch (IOException e) {
			// TODO wrap with custom exception
			e.printStackTrace();
		} 
		return commandList;
	}
}
