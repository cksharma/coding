/**
 * 
 */
package utils;

/**
 * @author Tanvi
 *
 */
public final class Constants {
	public static final String OUTPUT_FILE = "prog5.out";
	public static final int COMMAND_POS = 10;
	public static final int ARGUMENT_POS = 17;
	public static final int WIDTH_DIR = 8;
	public static final char EOF = '\n';
	public static final String COMMAND_SPLIT_REGEX = "\\s+";
	public static final String MKDIR = "mkdir";
	public static final String CD = "cd";
	public static final String DIR = "dir";
	public static final String UP = "up";
	public static final String FOLDER_PRESENT = "Subdirectory already exists";
	public static final String FOLDER_DOESNT_EXIST = "Subdirectory does not exist";
	public static final String CANNOT_MOVE_UP = "Cannot move up from root directory";
	public static final String ROOT = "root";
	public static final String PROJECT_START = "Problem 5 by team X";
	public static final String PROJECT_END = "End of problem 5 by team X";
	public static final String DIRECTORY_OF = "Directory of";
	public static final String COLON = ":";
	public static final String NO_SUB_DIRS = "No subdirectories";
	
	private Constants() {
		
	}
}
